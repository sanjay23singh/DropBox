import 'package:firebase_auth/firebase_auth.dart';

class FirebaseMethods {
  FirebaseAuth auth = FirebaseAuth.instance;

  createUserWithEmailAndPassword(
      String _email, String _password) async {
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _email,
        password: _password,
      );
    } catch (e) {
      print(e.toString());
    }
  }

  loginWithEmailAndPassword(String _email, String _password) async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email,
        password: _password,
      );

      print('Sign in Successful');
    } catch (e) {
      print(e);
    }
  }
}
