import 'package:DropBox/utilites/FirebaseRepos.dart';
import 'package:DropBox/utilites/Universal.dart';
import 'package:flutter/material.dart';
import 'package:email_validator/email_validator.dart';

class RegisterScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RegisterScreenApp(),
    );
  }
}

class RegisterScreenApp extends StatefulWidget {
  @override
  RegisterScreenAppState createState() => RegisterScreenAppState();
}

class RegisterScreenAppState extends State<RegisterScreenApp> {
  FirebaseRepos _repos = new FirebaseRepos();
  TextEditingController _userName = new TextEditingController();
  TextEditingController _email = new TextEditingController();
  TextEditingController _password = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              Expanded(
                  child: Container(
                color: Colors.blue,
                child: Center(child: Text("DropBox")),
              )),
              Column(
                children: [
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: TextField(
                      controller: _userName,
                      decoration: InputDecoration(
                        labelText: 'User name',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: TextField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: TextField(
                      controller: _password,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                    alignment: Alignment.centerRight,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Already registered ?, ", style: TextStyle()),
                        InkWell(
                            onTap: () {
                              Navigator.of(context).pushReplacementNamed('login');
                            },
                            child: Text("Login",
                                style: TextStyle(
                                    decoration: TextDecoration.underline))),
                      ],
                    ),
                  ),
                  RaisedButton(
                    onPressed: () {
                      if (EmailValidator.validate(_email.text) &&
                          _userName.text.length >= 4 &&
                          _password.text.length >= 6)
                        _repos.createUserWithEmailAndPassword(
                            _email.text, _password.text);
                      else if (!EmailValidator.validate(_email.text))
                        showSnackBar(context, "Invalid Email");
                      else if (_userName.text.length < 4)
                        showSnackBar(
                            context, 'username must be minimum of length 4');
                      else
                        showSnackBar(
                            context, 'password should be minimum of length 6');
                    },
                    child: Text("Register"),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
