import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';


class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  void pickFile()async{
    FilePickerResult result = await FilePicker.platform.pickFiles();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('DropBox'),),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          pickFile();
        },
        child: Icon(Icons.add),
      ),
    );
  }
}