import 'package:DropBox/utilites/FirebaseRepos.dart';
import 'package:DropBox/utilites/Universal.dart';
import 'package:flutter/material.dart';
import 'package:email_validator/email_validator.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LoginScreenApp(),
    );
  }
}

class LoginScreenApp extends StatefulWidget {
  @override
  LoginScreenAppState createState() => LoginScreenAppState();
}

class LoginScreenAppState extends State<LoginScreenApp> {
  FirebaseRepos _repos=new FirebaseRepos();
  TextEditingController _email = new TextEditingController();
  TextEditingController _password = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              Expanded(
                  child: Container(
                color: Colors.blue,
                child: Center(child: Text("DropBox")),
              )),
              Column(
                children: [
                  
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: TextField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: TextField(
                      controller: _password,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
                    alignment: Alignment.centerRight,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Not registered yet ?, ", style: TextStyle()),
                        InkWell(
                            onTap: () {
                              Navigator.of(context).pushReplacementNamed('register');
                            },
                            child: Text("Register",
                                style: TextStyle(
                                    decoration: TextDecoration.underline))),
                      ],
                    ),
                  ),
                  RaisedButton(
                    onPressed: () {
                      if (EmailValidator.validate(_email.text)&&_password.text.length>=0) 
                      _repos.loginWithEmailAndPassword(_email.text, _password.text).then((_){
                        Navigator.popAndPushNamed(context, 'homeScreen');
                      });
                      else if(!EmailValidator.validate(_email.text))
                      showSnackBar(context, "Invalid Email");
                      else showSnackBar(context, 'password should not be empty');
                    },
                    child: Text("Login"),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
