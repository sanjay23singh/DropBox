import 'package:DropBox/utilites/FirebaseMEthods.dart';

class FirebaseRepos
{
  FirebaseMethods methods=new FirebaseMethods();
  createUserWithEmailAndPassword(String _email,String _password)=>methods.createUserWithEmailAndPassword(_email, _password);
  loginWithEmailAndPassword(String _email, String _password) =>methods.loginWithEmailAndPassword(_email, _password);
}