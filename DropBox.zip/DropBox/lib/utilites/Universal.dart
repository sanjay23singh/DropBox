import 'package:flutter/material.dart';

showSnackBar(BuildContext context, String text)
{
  return Scaffold.of(context).showSnackBar(SnackBar(content: Text(text),duration: Duration(milliseconds: 3000),));
}

